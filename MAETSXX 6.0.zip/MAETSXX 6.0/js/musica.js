(function () {
  var SRC = 'audio/natal.mp3';
  var K_TEMPO = 'maetsxx_musica_tempo';
  var K_MUDO = 'maetsxx_musica_mudo';

  var audio = document.createElement('audio');
  audio.id = 'musicaFundo';
  audio.src = SRC;
  audio.loop = true;
  audio.preload = 'auto';
  audio.volume = 0.4;
  document.body.appendChild(audio);

  function ler(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function gravar(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }

  var mudo = ler(K_MUDO) === '1';

  var estilo = document.createElement('style');
  estilo.textContent =
    '.btn-musica{position:fixed;left:16px;bottom:16px;z-index:9999;width:46px;height:46px;' +
    'border-radius:50%;border:2px solid #fff;background:#274B44;color:#fff;font-size:22px;' +
    'cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.4);line-height:1;padding:0}' +
    '.btn-musica:hover{transform:scale(1.08)}';
  document.head.appendChild(estilo);

  var btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'btn-musica';
  document.body.appendChild(btn);

  function atualizarBotao() {
    var tocando = !mudo && !audio.paused;
    btn.textContent = mudo ? '\uD83D\uDD07' : '\uD83D\uDD0A';
    btn.setAttribute('aria-label', mudo ? 'Ligar música' : 'Desligar música');
    btn.title = btn.getAttribute('aria-label');
    btn.style.opacity = tocando || mudo ? '1' : '.7';
  }

  var t = parseFloat(ler(K_TEMPO));
  audio.addEventListener('loadedmetadata', function () {
    if (!isNaN(t) && t > 0 && t < audio.duration) { try { audio.currentTime = t; } catch (e) {} }
  });

  function salvarTempo() { if (!isNaN(audio.currentTime)) gravar(K_TEMPO, audio.currentTime); }
  audio.addEventListener('timeupdate', salvarTempo);
  window.addEventListener('pagehide', salvarTempo);
  window.addEventListener('beforeunload', salvarTempo);

  var gestos = ['pointerdown', 'keydown', 'touchstart', 'click', 'wheel', 'scroll'];
  function removerGestos() { gestos.forEach(function (g) { window.removeEventListener(g, aoInteragir, true); }); }
  function aoInteragir() { if (!mudo) tocar(); }

  function tocar() {
    var p = audio.play();
    if (p && p.then) {
      p.then(function () { removerGestos(); atualizarBotao(); })
       .catch(function () { /* o navegador bloqueou; tenta de novo no primeiro gesto */ });
    }
  }

  btn.addEventListener('click', function (e) {
    e.stopPropagation();
    mudo = !mudo;
    gravar(K_MUDO, mudo ? '1' : '0');
    if (mudo) { audio.pause(); } else { tocar(); }
    atualizarBotao();
  });

  atualizarBotao();
  if (!mudo) {
    tocar(); // tenta tocar já ao abrir a página
    gestos.forEach(function (g) { window.addEventListener(g, aoInteragir, true); });
  }
})();

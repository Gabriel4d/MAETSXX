
document.addEventListener('DOMContentLoaded', () => {
    const $ = (s, r = document) => r.querySelector(s);
    const $$ = (s, r = document) => [...r.querySelectorAll(s)];

    const body = document.body;
    const menu = $('.menu-toggle');
    const nav = $('.main-nav');

    if (menu && nav) {
        menu.addEventListener('click', () => {
            const open = nav.classList.toggle('open');

            menu.setAttribute('aria-expanded', String(open));
            menu.textContent = open ? '×' : '☰';
        });

        $$('a', nav).forEach(a => {
            a.addEventListener('click', () => {
                nav.classList.remove('open');
                menu.setAttribute('aria-expanded', 'false');
                menu.textContent = '☰';
            });
        });
    }
    const THEME_KEY = 'maetsxx-tema';
    const root = document.documentElement;
    const themeBtn = document.createElement('button');
    themeBtn.type = 'button';
    themeBtn.className = 'theme-toggle';
    const applyTheme = dark => {
        if (dark) {
            root.setAttribute('data-tema', 'escuro');
        } else {
            root.removeAttribute('data-tema');
        }
        themeBtn.textContent = dark ? '☀' : '☾';
        themeBtn.setAttribute('aria-label', dark ? 'Ativar modo claro' : 'Ativar modo escuro');
        themeBtn.title = themeBtn.getAttribute('aria-label');
    };
    let savedTheme = null;
    try {
        savedTheme = localStorage.getItem(THEME_KEY);
    } catch (err) {}

    applyTheme(savedTheme === 'escuro');

    themeBtn.addEventListener('click', () => {
        const dark = root.getAttribute('data-tema') !== 'escuro';
        applyTheme(dark);
        try {
            localStorage.setItem(THEME_KEY, dark ? 'escuro' : 'claro');
        } catch (err) {}
    });

    if (nav) {
        nav.append(themeBtn);
    }

    const topBtn = $('.back-top');

    const onScroll = () => {
        if (topBtn) {
            topBtn.classList.toggle('visible', window.scrollY > 350);
        }
    };

    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    if (topBtn) {
        topBtn.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }
    $$('.year').forEach(el => {
        el.textContent = new Date().getFullYear();
    });

    // Animação de entrada dos elementos
    const revealItems = $$('.reveal');

    if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver(
            entries => entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                    observer.unobserve(entry.target);
                }
            }),
            { threshold: 0.12 }
        );

        revealItems.forEach(el => observer.observe(el));
    } else {
        revealItems.forEach(el => el.classList.add('is-visible'));
    }

    // Efeito de neve
    const snow = $('.snow-layer');

    if (snow && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        let made = 0;

        const spawn = () => {
            if (made > 55) return;

            const flake = document.createElement('span');

            flake.className = 'snowflake';
            flake.textContent = ['❄', '✧', '·'][Math.floor(Math.random() * 3)];
            flake.style.left = Math.random() * 100 + '%';
            flake.style.opacity = (0.35 + Math.random() * 0.6).toFixed(2);
            flake.style.fontSize = (7 + Math.random() * 10) + 'px';
            flake.style.setProperty('--drift', (Math.random() * 120 - 60) + 'px');
            flake.style.animationDuration = (7 + Math.random() * 9) + 's';

            snow.append(flake);
            made++;

            flake.addEventListener('animationend', () => {
                flake.remove();
                made--;
            });
        };

        for (let i = 0; i < 16; i++) {
            setTimeout(spawn, i * 250);
        }

        setInterval(spawn, 650);
    }
    const countdowns = $$('[data-countdown]');

    if (countdowns.length) {
        const update = () => {
            const now = new Date();
            const year = now.getFullYear();

            let christmas = new Date(year, 11, 25, 0, 0, 0);

            if (now >= christmas) {
                christmas = new Date(year + 1, 11, 25, 0, 0, 0);
            }

            let secs = Math.max(
                0,
                Math.floor((christmas - now) / 1000)
            );

            const d = Math.floor(secs / 86400);
            secs %= 86400;

            const h = Math.floor(secs / 3600);
            secs %= 3600;

            const m = Math.floor(secs / 60);
            const s = secs % 60;

            countdowns.forEach(el => {
                const set = (key, val) => {
                    const e = el.querySelector('[data-' + key + ']');

                    if (e) {
                        e.textContent = String(val).padStart(2, '0');
                    }
                };

                set('days', d);
                set('hours', h);
                set('minutes', m);
                set('seconds', s);
            });
        };

        update();
        setInterval(update, 1000);
    }

    // Slides da página inicial
    const slides = $$('.home-slide');
    const dots = $$('.slide-dots button');

    if (slides.length) {
        let current = 0;

        const showSlide = (next) => {
            current = (next + slides.length) % slides.length;

            slides.forEach((slide, i) => {
                const active = i === current;

                slide.classList.toggle('is-active', active);
                slide.setAttribute('aria-hidden', String(!active));
            });

            dots.forEach((dot, i) => {
                const active = i === current;

                dot.classList.toggle('is-active', active);

                if (active) {
                    dot.setAttribute('aria-current', 'true');
                } else {
                    dot.removeAttribute('aria-current');
                }
            });
        };

        $('.slide-prev')?.addEventListener('click', () => {
            showSlide(current - 1);
        });

        $('.slide-next')?.addEventListener('click', () => {
            showSlide(current + 1);
        });

        dots.forEach((dot, i) => {
            dot.addEventListener('click', () => {
                showSlide(i);
            });
        });

        let slideTimer = setInterval(() => {
            showSlide(current + 1);
        }, 6000);

        const slideshow = $('.home-slideshow');

        slideshow?.addEventListener('mouseenter', () => {
            clearInterval(slideTimer);
        });

        slideshow?.addEventListener('mouseleave', () => {
            clearInterval(slideTimer);

            slideTimer = setInterval(() => {
                showSlide(current + 1);
            }, 6000);
        });

        slideshow?.addEventListener('focusin', () => {
            clearInterval(slideTimer);
        });

        slideshow?.addEventListener('focusout', () => {
            clearInterval(slideTimer);

            slideTimer = setInterval(() => {
                showSlide(current + 1);
            }, 6000);
        });
    }
    const form = $('#contact-form');

    if (form) {
        const fields = [
            ['contact-name', 'name-error', 'Digite seu nome.'],
            ['contact-email', 'email-error', 'Digite um e-mail válido.'],
            ['contact-subject', 'subject-error', 'Informe o assunto.'],
            ['contact-message', 'message-error', 'Escreva sua mensagem.']
        ];

        form.addEventListener('submit', e => {
            e.preventDefault();

            let valid = true;

            fields.forEach(([id, errId, msg]) => {
                const input = $('#' + id);
                const err = $('#' + errId);

                let issue = '';

                if (!input.value.trim()) {
                    issue = msg;
                } else if (
                    id === 'contact-email' &&
                    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value.trim())
                ) {
                    issue = 'Confira o formato do e-mail.';
                }

                err.textContent = issue;

                input.classList.toggle('input-error', !!issue);
                input.setAttribute('aria-invalid', String(!!issue));

                if (issue) {
                    valid = false;
                }
            });

            const feedback = $('#form-feedback');

            if (valid) {
                feedback.className = 'form-feedback success';

                feedback.textContent =
                    'Mensagem validada com sucesso! Como esta é uma demonstração escolar, ela não foi enviada de verdade.';

                form.reset();
            } else {
                feedback.className = 'form-feedback error';

                feedback.textContent =
                    'Revise os campos destacados antes de continuar.';
            }
        });

        fields.forEach(([id, errId]) => {
            $('#' + id).addEventListener('input', () => {
                const input = $('#' + id);

                if (input.value.trim()) {
                    input.classList.remove('input-error');
                    input.setAttribute('aria-invalid', 'false');

                    $('#' + errId).textContent = '';
                }
            });
        });
    }
    const lightbox = $('#lightbox');

    if (lightbox) {
        const emoji = $('#lightbox-emoji');
        const caption = $('#lightbox-caption');

        document.addEventListener('click', e => {
            const tile = e.target.closest('[data-lightbox]');

            if (!tile) return;

            const src = tile.dataset.lightbox;
            const alt = tile.dataset.caption || 'Imagem ampliada';

            emoji.textContent = '';

            if (/[\/.]/.test(src)) {
                const img = document.createElement('img');
                img.src = src;
                img.alt = alt;
                emoji.append(img);
            } else {
                emoji.textContent = src;
            }

            caption.textContent = tile.dataset.caption || '';

            lightbox.classList.add('is-open');
            lightbox.setAttribute('aria-hidden', 'false');
        });

        const close = () => {
            lightbox.classList.remove('is-open');
            lightbox.setAttribute('aria-hidden', 'true');
        };

        $('.lightbox-close', lightbox).addEventListener('click', close);

        lightbox.addEventListener('click', e => {
            if (e.target === lightbox) {
                close();
            }
        });

        document.addEventListener('keydown', e => {
            if (e.key === 'Escape') {
                close();
            }
        });
    }
});
